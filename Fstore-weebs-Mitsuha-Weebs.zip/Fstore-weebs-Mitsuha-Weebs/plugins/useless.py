from bot import Bot
from pyrogram.types import Message
from pyrogram import filters
from config import ADMINS, BOT_STATS_TEXT, USER_REPLY_TEXT, SUDO
from datetime import datetime
from database.database import get_admins, get_admin_ids
from helper_func import get_readable_time




@Bot.on_message(filters.command('ping'))
async def stats(bot: Bot, message: Message):
    
    now = datetime.now()
    delta = now - bot.uptime
    time = get_readable_time(delta.seconds)
    admin_ids = await get_admin_ids()
    user_id = message.from_user.id
    if user_id in admin_ids:
        await message.reply(BOT_STATS_TEXT.format(uptime=time))


#@Bot.on_message(filters.private & filters.incoming & ~filters.command(['start']))
#async def useless(_,message: Message):
#    if USER_REPLY_TEXT:
#        await message.reply(USER_REPLY_TEXT)
